from flask import Flask, render_template, jsonify,json,request,redirect
from flask_pymongo import PyMongo
import pymongo
import random

app = Flask(__name__)
app.config['MONGO_URI'] = 'mongodb://localhost:27017/hotelCollection'
mongo = PyMongo(app)
details = list()


jobs=['House Keeping to clean','Arrange rooms of various floors','Kitchen Mangement','Customer Management','Managing Hotel tasks']

@app.route('/')
def logn():
    for i in collection.find():
        details.append(i)
        
    return render_template("login.html")

@app.route('/Register')
def register():
    return render_template("Register.html")

@app.route('/dashboard')
def home():
    alldocs=collection.find().skip(1) 
    return render_template('Dashboard.html',alldocs=alldocs)

@app.route('/employee')
def employee():
    
    return render_template('Dashboard.html')





@app.route('/', methods=['GET','POST'])
def something():
    if request.method=='POST':
        for key,val in request.form.items():
            if key == 'username':
                username = val    
            else:
                password = val
        filtered=[d for d in details if condition(d, username, password)]
        for i in filtered:
            a=i['username']
            b=i['password']
        
    if filtered:
        if a=="admin" and b=="admin123":
            alldocs=collection.find().skip(1)
            return render_template('/dashboard.html',alldocs=alldocs)
        user=collection.find({"username" :username})
        print(user)
        alldocs=collection.find({'username':username})
        return render_template('/employee.html',alldocs=alldocs)
    else:
        
        return ('"Wrong Username or Password"')

def condition(dict, username, password):
    
    return dict['username'] == username  and dict['password'] == password


@app.route('/adduser', methods=['GET','POST'])
def adduser():
      
    if request.method=='POST':
        empid=request.form['empid']
        name=request.form['name']
        jobrole=request.form['jobrole']
        username=request.form['username']
        print(username)
        password=request.form['password']
        
        input_dict={'empid':empid,"name":name,"jobrole":jobrole,"username":username,'password':password,'work':'Currently not available'}

    if collection.count_documents({'username':  username}, limit=1) != 0:
        return render_template('register.html')
    else:
        collection.insert_one(input_dict)
        return redirect("/")   

@app.route('/update1/<string:username>')
def update1(username):
    myquery = {"username":username}
    newvalues = {"$set":{"work":random.choice(jobs)}}
    collection.update_one(myquery, newvalues)
    alldocs=collection.find().skip(1)
    return render_template("dashboard.html",alldocs=alldocs)


@app.route('/delete/<string:username>')
def delete(username):
    collection.delete_one({'username':username})
    alldocs=collection.find().skip(1)
    return render_template("dashboard.html",alldocs=alldocs)


if __name__=="__main__":
    print('Welcome to Pymongo')
    client = pymongo.MongoClient("mongodb://localhost:27017")
    print(client)
    db=client['HMSDB']
    collection=db['hotelCollection']
    user_data = {'_id': 1, 'username':'admin', 'password':'admin123'}
    #collection.insert_one(user_data)
    
    
    for i in collection.find():
        details.append(i)
        
    app.run(debug=True,port=8000)